package com.coffeepoweredcrew.objectpool;

public interface Poolable {

	//state reset
	void reset();
}
