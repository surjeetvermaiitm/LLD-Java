package com.coffeepoweredcrew.abstractfactory2;

//Represents an abstract product
public interface Storage {

    String getId();

}
