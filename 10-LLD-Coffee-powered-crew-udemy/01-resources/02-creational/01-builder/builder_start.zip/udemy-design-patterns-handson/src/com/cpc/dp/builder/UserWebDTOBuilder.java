package com.cpc.dp.builder;

//The concrete builder for UserWebDTO
//TODO implement builder
public class UserWebDTOBuilder /*implements UserDTOBuilder */{
	
	
}
