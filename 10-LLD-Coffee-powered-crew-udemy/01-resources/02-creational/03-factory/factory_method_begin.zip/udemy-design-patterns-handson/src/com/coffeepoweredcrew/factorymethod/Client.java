package com.coffeepoweredcrew.factorymethod;

import com.coffeepoweredcrew.factorymethod.message.Message;

public class Client {

	public static void main(String[] args) {
		
	}
	
	public static void printMessage(MessageCreator creator) {
		
	}
}
