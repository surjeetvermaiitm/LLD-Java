package com.company.depinv;

public interface Formatter {
	
	public String format(Message message) throws FormatException;
	
}
