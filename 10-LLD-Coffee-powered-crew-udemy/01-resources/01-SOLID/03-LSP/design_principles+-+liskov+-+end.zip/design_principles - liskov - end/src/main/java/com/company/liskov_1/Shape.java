package com.company.liskov_1;

public interface Shape {
	
	public int computeArea();
	
}
