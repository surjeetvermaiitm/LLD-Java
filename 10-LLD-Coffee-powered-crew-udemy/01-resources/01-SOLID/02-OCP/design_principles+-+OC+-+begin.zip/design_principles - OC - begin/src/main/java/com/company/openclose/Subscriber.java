package com.company.openclose;


public class Subscriber {

}
