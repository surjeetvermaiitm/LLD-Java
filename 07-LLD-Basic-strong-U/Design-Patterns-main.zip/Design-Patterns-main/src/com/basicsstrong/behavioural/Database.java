package com.basicsstrong.behavioural;

public interface Database {
	
	public String connect();

}
