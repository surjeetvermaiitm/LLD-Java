package com.basicsstrong.behavioural;

public class PlainBurger implements Burger {
	 public String makeBurger(){
		 	return "Burger is ready";
		 }

}
