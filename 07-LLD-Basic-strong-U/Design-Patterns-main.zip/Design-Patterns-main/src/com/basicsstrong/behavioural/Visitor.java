package com.basicsstrong.behavioural;

public interface Visitor {

	public void visit(Visitable vis);
	
}
