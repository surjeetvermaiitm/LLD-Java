package com.basicsstrong.behavioural;

public class RDBMS implements Database {
	
	@Override
	public String connect() {
		return "Connection successfull to RDBMS.";
	}
	

}
