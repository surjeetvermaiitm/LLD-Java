package com.basicsstrong.behavioural;

public class DBMS implements Database {
	
	@Override
	public String connect() {
		return "Connection Successfull with DBMS.";
	}

}
