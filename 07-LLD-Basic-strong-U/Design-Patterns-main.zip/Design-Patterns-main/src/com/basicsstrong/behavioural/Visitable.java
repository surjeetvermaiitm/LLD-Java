package com.basicsstrong.behavioural;

public interface Visitable {
	
	public void accept(Visitor v);

}
