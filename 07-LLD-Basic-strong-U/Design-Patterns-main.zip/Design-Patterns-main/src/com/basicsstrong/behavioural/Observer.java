package com.basicsstrong.behavioural;

public interface Observer {

	public void update(String avail);
}
