package com.basicsstrong.behavioural;

public interface Strategy {
	
	public void compressFile(String Filename);
	

}
