package com.basicsstrong.behavioural;

public class VisitorDesignPattern {

	public static void main(String[] args) {

		Organisation.ratings();
	}

}
