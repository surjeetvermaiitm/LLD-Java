package com.basicsstrong.behavioural;

public interface EmployeeState {
	public void work();
	
	public void canApproveLeave();
	

}
