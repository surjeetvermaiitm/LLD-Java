package com.basicsstrong.behavioural;

public interface Burger{
    public String makeBurger();
}
