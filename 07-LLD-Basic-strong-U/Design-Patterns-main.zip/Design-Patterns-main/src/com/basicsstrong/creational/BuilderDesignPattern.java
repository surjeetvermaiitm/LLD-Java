package com.basicsstrong.creational;

public class BuilderDesignPattern {

	public static void main(String[] args) {

     Mobile m = Manufracturer.createCompleteObject();
  
     System.out.println("m");
  
  
	}

}
