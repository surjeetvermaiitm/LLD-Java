package com.basicsstrong.creational;

public class MsAccess implements Database {
	
	@Override
	public String connect() {
		return "Connection Successful with MsAccess DB.";
		
	}

}
