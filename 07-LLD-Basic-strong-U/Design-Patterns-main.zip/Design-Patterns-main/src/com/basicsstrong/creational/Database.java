package com.basicsstrong.creational;

public interface Database {
	
	public String connect();

}
