package com.basicsstrong.creational;

public class XML implements Database {

	@Override
	public String connect() {
		return "Connection Successful with XML.";
		
	}

}
