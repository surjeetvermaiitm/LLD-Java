package com.basicsstrong.creational;

public class MySql implements Database {
	
	@Override
	public String connect() {
		return "Connection Successfull with MySql DB.";
		
	}

}
