package com.basicsstrong.structural;

public interface Color {
	
	public void pickColor();

}
