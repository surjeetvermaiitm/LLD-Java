package com.basicsstrong.designprinciples;

interface Worker{
	public void work();
}

interface Sleep{
	
}

class Human implements Worker, Sleep{  

@Override
public void work() {
	// TODO Auto-generated method stub
	
}

public void sleep() {
	// TODO Auto-generated method stub
	
}

}

class Robot implements Worker{
	
	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}
	
}
public class ISP {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		}		
		
}