package com.basicsstrong.oop;

public abstract  class AbstractDemo {
	
	//we can not create object of abstract class
	
	public abstract void method(); 

}
