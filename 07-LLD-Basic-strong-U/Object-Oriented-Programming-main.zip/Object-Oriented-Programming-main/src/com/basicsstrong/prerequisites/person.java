package com.basicsstrong.prerequisites;

import com.basicsstrong.business.Company;

public class Person extends Company {

	public static void main(String[] args) {
      //Company com = new Company();
		Person p = new Person();
      com.enrollEmployee("Shiva");
      
	}

}
